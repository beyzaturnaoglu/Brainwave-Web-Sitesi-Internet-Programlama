from flask import Flask, request, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
from flask import Flask, request, redirect, render_template, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'sdsadsagfgd987fd8sfsd'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'
db = SQLAlchemy(app)


login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'


class Admin(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)


@login_manager.user_loader
def load_user(user_id):
    return Admin.query.get(int(user_id))


class DetailBox(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    text = db.Column(db.String(500), nullable=False)


class AboutUs(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    text = db.Column(db.String(500), nullable=False)


class WhatWeDo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    text = db.Column(db.String(500), nullable=False)


class OurSkills(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    skill_name = db.Column(db.String(100), nullable=False)


class Contact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50))
    email = db.Column(db.String(50))
    phone = db.Column(db.String(20))
    message = db.Column(db.String(500))

@app.route('/add_whatwedo', methods=['POST'])
def add_whatwedo():
    title = request.form['title']
    text = request.form['text']
    new_whatwedo = WhatWeDo(title=title, text=text)
    db.session.add(new_whatwedo)
    db.session.commit()
    return redirect('/admin')

@app.route('/delete_whatwedo/<int:id>', methods=['POST'])
def delete_whatwedo(id):
    whatwedo_to_delete = WhatWeDo.query.get_or_404(id)
    db.session.delete(whatwedo_to_delete)
    db.session.commit()
    return redirect('/admin')

@app.route('/add_detailbox', methods=['POST'])
def add_detailbox():
    title = request.form['title']
    text = request.form['text']
    new_detail = DetailBox(title=title, text=text)
    db.session.add(new_detail)
    db.session.commit()
    return redirect('/admin')

@app.route('/delete_detailbox/<int:id>', methods=['POST'])
def delete_detailbox(id):
    detail_to_delete = DetailBox.query.get_or_404(id)
    db.session.delete(detail_to_delete)
    db.session.commit()
    return redirect('/admin')



with app.app_context():
    db.create_all()
    if not Admin.query.filter_by(username='admin').first():
        new_admin = Admin(username='admin',
                          password=generate_password_hash('admin123'))
        db.session.add(new_admin)
        db.session.commit()

    if not DetailBox.query.first():
        samples = [
            DetailBox(title="Başlık 1", text="Metin 1"),
            DetailBox(title="Başlık 2", text="Metin 2"),
            DetailBox(title="Başlık 3", text="Metin 3")
        ]
        db.session.bulk_save_objects(samples)
        db.session.commit()

    if not AboutUs.query.first():
        about_us_entry = AboutUs(
            title="Hakkımızda", text="Bizim hakkımızda metni.")
        db.session.add(about_us_entry)
        db.session.commit()

    if WhatWeDo.query.count() == 0:
        activities = [
            WhatWeDo(title="Başlık 1", text="Metin 1"),
            WhatWeDo(title="Başlık 2", text="Metin 2"),
            WhatWeDo(title="Başlık 3", text="Metin 3"),
            WhatWeDo(title="Başlık 4", text="Metin 4")
        ]
        db.session.bulk_save_objects(activities)
        db.session.commit()

    if OurSkills.query.count() == 0:
        skills = [
            OurSkills(skill_name="Logo Design"),
            OurSkills(skill_name="Coding"),
            OurSkills(skill_name="Bike Design"),
            OurSkills(skill_name="Flower Design"),
            OurSkills(skill_name="Website Design"),
            OurSkills(skill_name="Celebrate"),
        ]
        db.session.bulk_save_objects(skills)
        db.session.commit()


@app.route('/admin')
@login_required
def admin_panel():
    detailbox = DetailBox.query.all()
    aboutus = AboutUs.query.all()
    whatwedo = WhatWeDo.query.all()
    ourskills = OurSkills.query.all()
    contacts = Contact.query.all()

    return render_template('admin_panel.html', detailbox=detailbox, aboutus=aboutus, whatwedo=whatwedo, ourskills=ourskills, contacts=contacts)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('admin_panel'))
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = Admin.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('admin_panel'))
    return render_template('login.html')


@app.route('/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/')
def index():
    details = DetailBox.query.all()
    about_us_info = AboutUs.query.first()
    what_we_do = WhatWeDo.query.all()
    skills = OurSkills.query.all()
    return render_template('index.html', details=details, about_us=about_us_info, what_we_do=what_we_do, skills=skills)


@app.route('/about')
def about():
    about_us_info = AboutUs.query.first()
    return render_template('about.html', about_us=about_us_info)


@app.route('/portfolio')
def portfolio():
    skills = OurSkills.query.all()
    return render_template('portfolio.html', skills=skills)


@app.route('/service')
def service():
    what_we_do = WhatWeDo.query.all()
    return render_template('service.html', what_we_do=what_we_do)

@app.route('/add_ourskills', methods=['POST'])
def add_ourskills():
    skill_name = request.form['skill_name']
    new_skill = OurSkills(skill_name=skill_name)
    db.session.add(new_skill)
    db.session.commit()
    return redirect('/admin')

@app.route('/delete_ourskills/<int:id>', methods=['POST'])
def delete_ourskills(id):
    skill_to_delete = OurSkills.query.get_or_404(id)
    db.session.delete(skill_to_delete)
    db.session.commit()
    return redirect('/admin')

@app.route('/update_detailbox/<int:id>', methods=['POST'])
def update_detailbox(id):
    detail = DetailBox.query.get_or_404(id)
    detail.title = request.form['title']
    detail.text = request.form['text']
    db.session.commit()
    return redirect('/admin')


@app.route('/update_aboutus/<int:id>', methods=['POST'])
def update_aboutus(id):
    about = AboutUs.query.get_or_404(id)
    about.title = request.form['title']
    about.text = request.form['text']
    db.session.commit()
    return redirect('/admin')


@app.route('/update_whatwedo/<int:id>', methods=['POST'])
def update_whatwedo(id):
    what = WhatWeDo.query.get_or_404(id)
    what.title = request.form['title']
    what.text = request.form['text']
    db.session.commit()
    return redirect('/admin')


@app.route('/update_ourskills/<int:id>', methods=['POST'])
def update_ourskills(id):
    skill = OurSkills.query.get_or_404(id)
    skill.skill_name = request.form['skill_name']
    db.session.commit()
    return redirect('/admin')


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':

        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        message = request.form['message']

        new_contact = Contact(name=name, email=email,
                              phone=phone, message=message)
        db.session.add(new_contact)
        db.session.commit()

        return redirect(url_for('contact'))

    return render_template('contact.html')


if __name__ == '__main__':
    app.run(debug=True)
